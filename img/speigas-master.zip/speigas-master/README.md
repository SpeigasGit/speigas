![Security Status](https://img.shields.io/security-headers?label=Security&url=https%3A%2F%2Fgithub.com&style=flat-square)
![Gluten Status](https://img.shields.io/badge/Gluten-Free-green.svg)
![Eco Status](https://img.shields.io/badge/ECO-Friendly-green.svg)


# Ski service website

This project is for a ski service company, which is called Speigas. This website is a one page site, where you can find the basic information about the services that the company provides.

This website is published at https://eglejuske.github.io/speigas/

Website design author: Eglė Juškevičienė


## Project features
- responsive design
- css animations
- form validations

## Authors
[Egle](https://github.com/EgleJuske/)